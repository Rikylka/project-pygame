import os
import sys
import pygame

# Изображение не получится загрузить
# без предварительной инициализации pygame
pygame.init()
size = width, height = 630, 450
screen = pygame.display.set_mode(size)


def terminate():
    pygame.quit()
    sys.exit()


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image


class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            pos_x * 70, pos_y * 50 + 50)


def generator_briks():
    screen.fill('black')
    n_walls = 0
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '#':
                Tile('wall', x, y)
                n_walls += 1
    return n_walls


all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
# создадим спрайт
sprite = pygame.sprite.Sprite()
# определим его вид
sprite.image = load_image("brick.png")
# и размеры
sprite.rect = sprite.image.get_rect()

tile_images = {
        'wall': load_image('brick.png')
    }

bomb_image = load_image("grass.png")


level = [".#######.", '#########', '#########', '.#######.']
generator_briks()


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            terminate()
    screen.fill('white')
    all_sprites.draw(screen)
    pygame.display.flip()
